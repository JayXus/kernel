#include <xen/arm/hypervisor.h>
